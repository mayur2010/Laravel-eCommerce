<?php

namespace Botble\Chart\Interfaces;

interface ChartInterface
{
    /**
     * @return mixed
     */
    public function init();
}
